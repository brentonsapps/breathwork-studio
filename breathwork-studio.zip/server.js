// server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Client, Environment } = require('square');
const { google } = require('googleapis');

const app = express();

// Middleware
app.use(cors());
app.use(express.json()); // Essential for reading JSON from Square and your Frontend

// 1. Initialize Square Client
const squareClient = new Client({
  accessToken: process.env.SQUARE_ACCESS_TOKEN,
  environment: Environment.Sandbox, // Change to Production when you're ready for real money
});

// 2. Initialize Google OAuth2 for Gmail
const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);
oauth2Client.setCredentials({ refresh_token: process.env.GOOGLE_REFRESH_TOKEN });
const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

// --- ENDPOINTS ---

/**
 * Endpoint to fetch classes from Square Catalog
 */
app.get('/api/classes', async (req, res) => {
  try {
    const response = await squareClient.catalogApi.listCatalog(undefined, 'ITEM');
    const classes = response.result.objects?.map(item => ({
      id: item.id,
      name: item.itemDatimport React from 'react';

const BreathworkUI = () => {
  return (
    <div className="min-h-screen bg-[#F9F8F6] text-[#2D3436] selection:bg-[#4A6741] selection:text-white">
      {/* Navigation */}
      <nav className="flex justify-between items-center px-8 py-8 md:px-16">
        <h1 className="text-2xl font-serif tracking-[0.2em] uppercase text-[#4A6741]">PranaSpace</h1>
        <div className="hidden md:flex space-x-12 text-sm uppercase tracking-widest text-gray-500 font-medium">
          <a href="#" className="hover:text-[#4A6741] transition">The Method</a>
          <a href="#" className="hover:text-[#4A6741] transition">Our Studio</a>
          <a href="#" className="hover:text-[#4A6741] transition">Journal</a>
        </div>
        <button className="border border-[#4A6741] text-[#4A6741] px-8 py-2.5 rounded-full hover:bg-[#4A6741] hover:text-white transition-all duration-300 text-sm uppercase tracking-tighter">
          Book Session
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative flex flex-col items-center justify-center text-center pt-20 pb-32 px-6">
        <div className="max-w-4xl">
          <span className="inline-block mb-4 text-xs uppercase tracking-[0.4em] text-gray-400 font-bold">
            Conscious Breathwork
          </span>
          <h2 className="text-6xl md:text-8xl font-serif leading-tight mb-8 text-[#2D3436]">
            Return to your <br />
            <span className="italic font-light">Natural Rhythm.</span>
          </h2>
          <p className="max-w-xl mx-auto text-lg text-gray-500 leading-relaxed mb-12">
            Experience a deeper state of being. Our guided sessions use somatic breath techniques 
            to release tension and reset your nervous system.
          </p>
          
          {/* Animated Breath Guide Preview */}
          <div className="flex items-center justify-center gap-4 mb-16">
            <div className="w-3 h-3 bg-[#4A6741] rounded-full animate-ping"></div>
            <span className="text-sm italic text-gray-400">Join 12 others breathing now</span>
          </div>
        </div>

        {/* Studio Categories */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-6xl px-4">
          <div className="group relative h-[450px] overflow-hidden rounded-2xl bg-gray-200">
            {/* Image Placeholder */}
            <div className="absolute inset-0 bg-[#4A6741]/20 group-hover:bg-[#4A6741]/40 transition-all duration-700"></div>
            <div className="absolute bottom-0 left-0 p-8 text-white text-left">
              <h4 className="text-2xl font-serif mb-2">The Foundation</h4>
              <p className="text-sm opacity-80 mb-4">60 Min • Beginner Friendly</p>
              <button className="text-xs uppercase tracking-widest border-b border-white pb-1">View Schedule</button>
            </div>
          </div>

          <div className="group relative h-[450px] overflow-hidden rounded-2xl bg-gray-300 md:-translate-y-8">
            <div className="absolute inset-0 bg-[#2D3436]/30 group-hover:bg-[#2D3436]/50 transition-all duration-700"></div>
            <div className="absolute bottom-0 left-0 p-8 text-white text-left">
              <h4 className="text-2xl font-serif mb-2">Deep Somatic</h4>
              <p className="text-sm opacity-80 mb-4">90 Min • Advanced Practice</p>
              <button className="text-xs uppercase tracking-widest border-b border-white pb-1">View Schedule</button>
            </div>
          </div>

          <div className="group relative h-[450px] overflow-hidden rounded-2xl bg-gray-200">
            <div className="absolute inset-0 bg-[#4A6741]/20 group-hover:bg-[#4A6741]/40 transition-all duration-700"></div>
            <div className="absolute bottom-0 left-0 p-8 text-white text-left">
              <h4 className="text-2xl font-serif mb-2">Restorative Flow</h4>
              <p className="text-sm opacity-80 mb-4">45 Min • Gentle Release</p>
              <button className="text-xs uppercase tracking-widest border-b border-white pb-1">View Schedule</button>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Bar */}
      <div className="bg-white py-12 border-y border-gray-100">
        <div className="max-w-6xl mx-auto px-8 flex flex-wrap justify-between items-center opacity-40 grayscale gap-8">
          <span className="font-serif text-xl italic">Vogue Wellness</span>
          <span className="font-serif text-xl italic">The Yoga Journal</span>
          <span className="font-serif text-xl italic">Somatic Daily</span>
          <span className="font-serif text-xl italic">MindBodyGreen</span>
        </div>
      </div>
    </div>
  );
};

export default BreathworkUI;
a.name,
      description: item.itemData.description,
      price: (item.itemData.variations[0].itemVariationData.priceMoney.amount / 100).toFixed(2),
      variationId: item.itemData.variations[0].id
    })) || [];
    res.json(classes);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch catalog" });
  }
});

/**
 * Endpoint to process Payment and Create Booking
 */
app.post('/api/book-session', async (req, res) => {
  const { sourceId, serviceId, startAt, customerEmail, customerName } = req.body;

  try {
    // A. Create the Payment in Square
    const { result: payment } = await squareClient.paymentsApi.createPayment({
      sourceId: sourceId,
      idempotencyKey: Buffer.from(Math.random().toString()).toString('base64'),
      amountMoney: { amount: 5000, currency: 'USD' } // Note: Pull price dynamically in production
    });

    // B. Create the Booking in Square Calendar
    const { result: booking } = await squareClient.bookingsApi.createBooking({
      booking: {
        locationId: process.env.LOCATION_ID,
        serviceVariationId: serviceId,
        startAt: startAt,
        customerNote: `Booked via website: ${customerName}`
      }
    });

    // C. Send Confirmation via Google Workspace (Gmail)
    const subject = "Your Breathwork Journey is Confirmed";
    const utf8Subject = `=?utf-8?B?${Buffer.from(subject).toString('base64')}?=`;
    const messageParts = [
      `To: ${customerEmail}`,
      'Content-Type: text/html; charset=utf-8',
      'MIME-Version: 1.0',
      `Subject: ${utf8Subject}`,
      '',
      `<h1>Hello ${customerName},</h1><p>Your session is confirmed for ${new Date(startAt).toLocaleString()}. We look forward to breathing with you.</p>`
    ];
    const rawMessage = Buffer.from(messageParts.join('\n'))
      .toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

    await gmail.users.messages.send({
      userId: 'me',
      requestBody: { raw: rawMessage }
    });

    res.json({ success: true, booking });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Port listener for Render
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Studio server breathing on port ${PORT}`));
